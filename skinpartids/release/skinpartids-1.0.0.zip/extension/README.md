## 功能

提取EXML中带有id的组件，并转换成皮肤部件的ts代码。

## 用法

打开一个EXML文档。使用快捷键 `Alt+C` 将EXML中带有id的组件对应的ts代码复制到剪切板，然后粘贴到对应的ts类中。

特别感谢：
http://blog.csdn.net/hero82748274/article/details/48975525

![](images/skinpartids1.png)

![](images/skinpartids2.gif)