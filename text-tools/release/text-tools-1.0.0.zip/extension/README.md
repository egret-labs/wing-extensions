## 功能


This is an example with some useful text manipulation tools.  These include:

* Common casing operations e.g. toUpper, ToLower, SwapCase, Reverse and more
* HTML encoding and Decoding
* ASCII Art

Thanks:

https://github.com/Microsoft/vscode-MDTools